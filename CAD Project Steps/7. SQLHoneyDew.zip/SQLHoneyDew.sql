use HoneyDew;

CREATE TABLE UpdatedList
(
Updated INT, 
DewList INT,
GroceryList INT,
ChoreList INT, 
UpdatedNotify INT, 
)